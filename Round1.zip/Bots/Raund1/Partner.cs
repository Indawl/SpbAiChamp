﻿using System.Linq;

namespace SpbAiChamp.Bots.Raund1
{
    public class Partner
    {
        public Price InitialPrice { get; private set; }
        public int PlanetId { get; private set; }

        public Price Price { get; private set; }
        public int Delay { get; private set; }

        public Partner(Price price, int id, int delay = 0)
        {
            PlanetId = id;
            InitialPrice = price;
            Delay = delay;

            Price = new Price(price);
        }
    }
}
