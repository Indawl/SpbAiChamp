﻿using System.Linq;
using SpbAiChamp.Model;
using System.Collections.Generic;
using System;

namespace SpbAiChamp.Bots.Raund1
{
    public class Price
    {
        public static int WORKER_ID = Enum.GetValues(typeof(Resource)).Cast<int>().Max() + 1;
        public static int MAX_ID = WORKER_ID + 1;

        public int[] values = new int[MAX_ID];

        public Price() { }

        public Price(Price price) => price.values.CopyTo(values, 0);

        public Price(IDictionary<Resource, int> resources, int workers)
        {
            if (resources != null)
                foreach (KeyValuePair<Resource, int> resource in resources)
                    values[(int)resource.Key] += resource.Value;

            values[WORKER_ID] += workers;
        }

        public Price(int workers, Resource? resource)
        {
            if (resource.HasValue)
              values[(int)resource.Value] += workers;

            values[WORKER_ID] += workers;
        }

        public bool IsInitial => values.All(_ => _ == 0);
        public int WorkerCount => values[WORKER_ID];

        internal Price Union(Price price)
        {
            throw new NotImplementedException();
        }
    }
}
