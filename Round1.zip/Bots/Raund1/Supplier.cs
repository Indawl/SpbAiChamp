﻿namespace SpbAiChamp.Bots.Raund1
{
    public class Supplier : Partner
    {
        public Supplier(Price price, int id, int delay = 0) : base(price, id, delay)
        {
        }
    }
}
