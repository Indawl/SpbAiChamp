﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpbAiChamp.Bots.Raund1
{
    public class Auction
    {
        public int SupplierId { get; }
        public int ConsumerId { get; }
        public Supplier Supplier { get; }
        public Consumer Consumer { get; }

        public int Cost { get; private set; }
        public Price Price { get; set; } = new Price();

        public Auction(int supplierId, int consumerId, Supplier supplier, Consumer consumer)
        {
            SupplierId = supplierId;
            ConsumerId = consumerId;

            Supplier = supplier;
            Consumer = consumer;

            Cost = CalculateCost(Supplier, Consumer);
        }

        public int CalculateCost(Supplier supplier, Consumer consumer)
        {
            return 1;
        }
    }
}
