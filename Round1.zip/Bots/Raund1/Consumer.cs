﻿using SpbAiChamp.Model;

namespace SpbAiChamp.Bots.Raund1
{
    public class Consumer : Partner
    {
        public BuildingType? BuildingType { get; private set; }
        public bool Done { get; set; } = false;
        public Consumer(Price price, int id, BuildingType? buildingType = null, int delay = 0) : base(price, id, delay)
        {
            BuildingType = buildingType;
        }
    }
}
