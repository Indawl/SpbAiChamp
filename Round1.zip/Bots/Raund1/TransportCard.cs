﻿using System;
using System.Collections.Generic;
using System.Linq;
using SpbAiChamp.Model;

namespace SpbAiChamp.Bots.Raund1
{
    public class TransportCard
    {
        public List<Supplier> Suppliers { get; set; }
        public List<Consumer> Consumers { get; set; }

        public Auction[][] Auctions { get; set; }

        public TransportCard(List<Supplier> suppliers, List<Consumer> consumers)
        {
            Suppliers = suppliers;
            Consumers = consumers;
        }

        public void GetActions(List<MoveAction> moveActions, List<BuildingAction> buildingActions)
        {
            // Own logic
            GenerateMap();

            // Unpack actions
            for (int i = 0; i < Suppliers.Count; i++)
                for (int j = 0; j < Consumers.Count; j++)
                    // Check is building action
                    if (Consumers[j].BuildingType.HasValue)
                    {
                        if (!Consumers[j].Done)
                            buildingActions.Add(new BuildingAction(Consumers[j].PlanetId, Consumers[j].BuildingType.Value));
                        Consumers[j].Done = true;
                    }
                    else // move action
                    {
                        int workerCount = Auctions[i][j].Price.WorkerCount;

                        for (int k = 0; k < Price.MAX_ID && workerCount > 0; k++)
                            if (Auctions[i][j].Price.values[k] > 0)
                            {
                                MoveAction moveAction = new MoveAction(Suppliers[i].PlanetId, Consumers[j].PlanetId,
                                                                       Math.Min(Auctions[i][j].Price.values[k], workerCount),
                                                                       (k == Price.WORKER_ID) ? null : (Resource)k);
                                workerCount -= moveAction.WorkerNumber;
                                moveActions.Add(moveAction);
                            }
                    }
        }

        private void GenerateMap()
        {
            // No suppliers...
            if (Suppliers.Count == 0) return;
            // No consumers...
            if (Consumers.Count == 0) return;

            // Init auctions
            Auctions = new Auction[Suppliers.Count][];

            for (int i = 0; i < Suppliers.Count; i++)
            {
                Auctions[i] = new Auction[Consumers.Count];

                for (int j = 0; j < Consumers.Count; j++)
                    Auctions[i][j] = new Auction(i, j, Suppliers[i], Consumers[j]);
            }

            // Initial transportation plan
            List<Auction>[] curAuctions = new List<Auction>[Price.MAX_ID];

            // Look all resources
            for (int k = 0; k < Price.MAX_ID; k++)
            {
                curAuctions[k] = new List<Auction>();

                // Look all suppliers,consumers and all resources with > 0
                for (int i = 0; i < Suppliers.Count; i++)
                    for (int j = 0; j < Consumers.Count; j++)
                        if (Suppliers[i].Price.values[k] > 0 && Consumers[j].Price.values[k] > 0)
                            curAuctions[k].Add(Auctions[i][j]);
            }

            for (int k = 0; k < Price.MAX_ID; k++)
            {
                curAuctions[k].Sort((a, b) => a.Cost.CompareTo(b.Cost));

                List<Auction> basisAuctions = new List<Auction>();

                foreach (Auction auction in curAuctions[k])
                {
                    auction.Price.values[k] = Math.Min(auction.Supplier.Price.values[k], auction.Consumer.Price.values[k]);

                    if (auction.Price.values[k] > 0)
                    {
                        basisAuctions.Add(auction);
                        auction.Supplier.Price.values[k] -= auction.Price.values[k];
                        auction.Consumer.Price.values[k] -= auction.Price.values[k];
                    }
                }

                // Determinate basis action
                int newBasisAuctionCount = Suppliers.Count + Consumers.Count + 1 - basisAuctions.Count;
                if (newBasisAuctionCount > 0)
                    for (int i = basisAuctions.Count - 1; i >= 0; i--)
                    {
                        if (basisAuctions[i].SupplierId > 0 && Auctions[basisAuctions[i].SupplierId - 1][basisAuctions[i].ConsumerId].Price.values[k] == 0)
                            basisAuctions.Add(Auctions[basisAuctions[i].SupplierId - 1][basisAuctions[i].ConsumerId]);
                        else if (basisAuctions[i].ConsumerId > 0 && Auctions[basisAuctions[i].SupplierId][basisAuctions[i].ConsumerId - 1].Price.values[k] == 0)
                            basisAuctions.Add(Auctions[basisAuctions[i].SupplierId][basisAuctions[i].ConsumerId - 1]);
                        else continue;

                        if (--newBasisAuctionCount == 0) break;
                    }

               // if (newBasisAuctionCount > 0) throw new NotImplementedException();
            }

            // Calculate potencial

            // Caclculate delta

            // If delta > 0 recalc potencial



        }
    }
}
